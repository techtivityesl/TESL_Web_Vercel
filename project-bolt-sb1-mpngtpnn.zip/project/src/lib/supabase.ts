// Supabase configuration removed - using Netlify Forms for contact form
export const supabase = null;